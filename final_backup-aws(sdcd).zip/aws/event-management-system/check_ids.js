const http = require('http');

http.get('http://localhost:8081/api/events', (resp) => {
  let data = '';

  resp.on('data', (chunk) => {
    data += chunk;
  });

  resp.on('end', () => {
    try {
        const events = JSON.parse(data);
        console.log("Total events:", events.length);
        if (events.length > 0) {
            console.log("IDs:", events.map(e => e.id).join(", "));
        } else {
            console.log("No events found.");
        }
    } catch (e) {
        console.error("Error parsing JSON:", e.message);
        console.log("Raw data:", data);
    }
  });

}).on("error", (err) => {
  console.log("Error: " + err.message);
});
