try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/events" -Method GET
    Write-Output $response.Content
} catch {
    $stream = $_.Exception.Response.GetResponseStream()
    $reader = New-Object System.IO.StreamReader($stream)
    Write-Output $reader.ReadToEnd()
}
