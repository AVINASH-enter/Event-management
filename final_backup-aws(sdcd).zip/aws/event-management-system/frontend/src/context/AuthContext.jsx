import React, { createContext, useState, useEffect } from 'react';
import Cookies from 'js-cookie';
import api from '../api/axios';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const storedUser = Cookies.get('user');
        if (storedUser) {
            setUser(JSON.parse(storedUser));
        }
        setLoading(false);
    }, []);

    const login = async (email, password) => {
        try {
            const response = await api.post('/auth/signin', { email, password });
            const { token, ...userData } = response.data;

            Cookies.set('token', token, { expires: 1 }); // 1 day
            Cookies.set('user', JSON.stringify(userData), { expires: 1 });
            setUser(userData);
            return true;
        } catch (error) {
            console.error("Login failed", error);
            return false;
        }
    };

    const register = async (userData) => {
        try {
            await api.post('/auth/signup', userData);
            return { success: true };
        } catch (error) {
            console.error("Registration failed", error);
            let message = "Registration failed. Please try again.";

            if (error.response) {
                if (error.response.data?.message) {
                    message = error.response.data.message;
                } else if (error.response.data && typeof error.response.data === 'object') {
                    // Handle validation errors returned as a map
                    const errorMessages = Object.values(error.response.data);
                    if (errorMessages.length > 0) {
                        message = errorMessages.join(', ');
                    }
                }
            } else if (error.request) {
                // The request was made but no response was received
                message = "Network Error: deeply check if the backend server is running on port 8081.";
            }

            return { success: false, message };
        }
    }

    const logout = () => {
        Cookies.remove('token');
        Cookies.remove('user');
        setUser(null);
    };

    return (
        <AuthContext.Provider value={{ user, login, logout, register, loading }}>
            {children}
        </AuthContext.Provider>
    );
};
