import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const Navbar = () => {
    const { user, logout } = useContext(AuthContext);
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    return (
        <nav className="navbar">
            <div className="container" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Link to="/" className="logo">
                    ⚡ EventMaster
                </Link>
                <div className="global-nav-links">
                    <Link to="/" className="nav-link">Home</Link>

                    {user ? (
                        <>
                            {user.role === 'ADMIN' && <Link to="/admin" className="nav-link">Admin Dashboard</Link>}
                            <Link to="/my-bookings" className="nav-link">My Bookings</Link>
                            <span className="user-greeting" style={{ marginLeft: '1rem' }}>Hi, {user.name}</span>
                            <button onClick={handleLogout} className="btn-nav-outline" style={{ marginLeft: '0.5rem' }}>Logout</button>
                        </>
                    ) : (
                        <>
                            <Link to="/login" className="nav-link">Login</Link>
                            <Link to="/register" className="btn-nav-primary" style={{ marginLeft: '0.5rem' }}>Register</Link>
                        </>
                    )}
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
