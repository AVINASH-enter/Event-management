import React from 'react';

const Footer = () => {
    return (
        <footer className="footer">
            <div className="container">
                <div className="footer-content">
                    <div className="footer-brand">
                        <h3>EventMaster</h3>
                        <p>Your gateway to unforgettable experiences.</p>
                    </div>
                    <div className="footer-links">
                        <div className="footer-section">
                            <h4>Company</h4>
                            <ul>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Careers</a></li>
                                <li><a href="#">Contact</a></li>
                            </ul>
                        </div>
                        <div className="footer-section">
                            <h4>Legal</h4>
                            <ul>
                                <li><a href="#">Terms of Service</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                            </ul>
                        </div>
                        <div className="footer-section">
                            <h4>Connect</h4>
                            <div className="social-links">
                                <a href="#" aria-label="Twitter">Twitter</a>
                                <a href="#" aria-label="Instagram">Instagram</a>
                                <a href="#" aria-label="LinkedIn">LinkedIn</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="footer-bottom">
                    <p>&copy; {new Date().getFullYear()} EventMaster. All rights reserved.</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
