import React, { useEffect, useState } from 'react';
import api from '../api/axios';
import { Link } from 'react-router-dom';
import { Line, Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, ArcElement } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, ArcElement);

const AdminDashboard = () => {
    const [activeTab, setActiveTab] = useState('dashboard');
    const [stats, setStats] = useState({});
    const [events, setEvents] = useState([]);
    const [bookings, setBookings] = useState([]);
    const [users, setUsers] = useState([]);

    useEffect(() => {
        fetchStats();
    }, []);

    const fetchStats = async () => {
        try {
            const res = await api.get('/admin/stats');
            setStats(res.data);
        } catch (err) { console.error(err); }
    };

    const fetchEvents = async () => {
        try {
            const res = await api.get('/events');
            setEvents(res.data);
        } catch (err) { console.error(err); }
    };

    const fetchBookings = async () => {
        try {
            const res = await api.get('/bookings/all');
            setBookings(res.data);
        } catch (err) { console.error(err); }
    };

    const fetchUsers = async () => {
        try {
            const res = await api.get('/admin/users');
            setUsers(res.data);
        } catch (err) { console.error(err); }
    };

    useEffect(() => {
        if (activeTab === 'events') fetchEvents();
        if (activeTab === 'bookings') fetchBookings();
        if (activeTab === 'users') fetchUsers();
    }, [activeTab]);

    const handleDeleteEvent = async (id) => {
        if (!window.confirm("Delete this event?")) return;
        try {
            await api.delete(`/events/${id}`);
            fetchEvents();
        } catch (err) {
            alert('Failed to delete event');
        }
    };

    const handleDownloadReport = async (type) => {
        try {
            const response = await api.get(`/admin/reports/bookings/export/${type}`, {
                responseType: 'blob',
            });
            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', `bookings_report.${type}`);
            document.body.appendChild(link);
            link.click();
            link.remove();
        } catch (error) {
            console.error('Download failed:', error);
            alert("Download failed. Please try again.");
        }
    };

    // Chart Data Generation
    const lineChartData = {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        datasets: [
            {
                label: 'Activity',
                data: [12, 19, 3, 5, 2, 3, 10].map(() => Math.floor(Math.random() * 50)),
                borderColor: 'rgba(255, 255, 255, 0.8)',
                backgroundColor: 'rgba(255, 255, 255, 0.2)',
                tension: 0.4,
                pointRadius: 4,
                pointBackgroundColor: '#fff'
            }
        ]
    };

    const doughnutData = {
        labels: ['Used', 'Free'],
        datasets: [
            {
                data: [stats.totalEvents || 10, 100 - (stats.totalEvents || 10)],
                backgroundColor: ['#3b82f6', '#e2e8f0'],
                borderWidth: 0,
            },
        ],
    };

    const chartOptions = {
        responsive: true,
        plugins: {
            legend: { display: false },
            title: { display: true, text: 'Weekly Activity', color: '#fff' }
        },
        scales: {
            x: { ticks: { color: 'rgba(255,255,255,0.7)' }, grid: { display: false } },
            y: { ticks: { color: 'rgba(255,255,255,0.7)' }, grid: { color: 'rgba(255,255,255,0.1)' } }
        }
    };

    const renderContent = () => {
        if (activeTab === 'dashboard') {
            return (
                <>
                    {/* Quick Access Stats */}
                    <div className="quick-stats-grid">
                        <div className="gradient-card card-blue">
                            <h3>Total Users</h3>
                            <div className="value">{stats.totalUsers || 0}</div>
                        </div>
                        <div className="gradient-card card-orange">
                            <h3>Active Events</h3>
                            <div className="value">{stats.totalEvents || 0}</div>
                        </div>
                        <div className="gradient-card card-pink">
                            <h3>Total Bookings</h3>
                            <div className="value">{stats.totalBookings || 0}</div>
                        </div>
                        <div className="gradient-card card-purple">
                            <h3>Revenue</h3>
                            <div className="value">$12.4k</div>
                        </div>
                    </div>

                    {/* Charts Section */}
                    <div className="charts-section">
                        <div className="chart-card purple-theme">
                            <Line options={chartOptions} data={lineChartData} />
                        </div>
                        <div className="chart-card">
                            <h3 style={{ marginBottom: '1rem' }}>Storage / Limits</h3>
                            <div style={{ width: '200px', margin: '0 auto' }}>
                                <Doughnut data={doughnutData} />
                            </div>
                            <div style={{ textAlign: 'center', marginTop: '1rem', color: 'var(--text-secondary)' }}>
                                {stats.totalEvents} Events Created
                            </div>
                        </div>
                    </div>
                </>
            );
        }

        if (activeTab === 'events') {
            return (
                <div className="card" style={{ background: 'white', padding: '2rem', borderRadius: '20px' }}>
                    <div className="dashboard-section-header">
                        <h2>Manage Events</h2>
                        <Link to="/admin/events/new" className="btn btn-primary">+ Add New Event</Link>
                    </div>
                    <table className="data-table">
                        <thead>
                            <tr><th>ID</th><th>Title</th><th>Date</th><th>Actions</th></tr>
                        </thead>
                        <tbody>
                            {events.map(e => (
                                <tr key={e.id}>
                                    <td>#{e.id}</td>
                                    <td style={{ fontWeight: '500' }}>{e.title}</td>
                                    <td>{new Date(e.dateTime).toLocaleDateString()}</td>
                                    <td><button onClick={() => handleDeleteEvent(e.id)} className="action-btn btn-delete">Delete</button></td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )
        }

        if (activeTab === 'bookings') {
            return (
                <div className="card" style={{ background: 'white', padding: '2rem', borderRadius: '20px' }}>
                    <h2>Recent Bookings</h2>
                    <table className="data-table" style={{ marginTop: '1rem' }}>
                        <thead>
                            <tr><th>ID</th><th>User</th><th>Event</th><th>Status</th></tr>
                        </thead>
                        <tbody>
                            {bookings.map(b => (
                                <tr key={b.id}>
                                    <td>#{b.id}</td>
                                    <td>{b.user.email}</td>
                                    <td>{b.event.title}</td>
                                    <td><span className="status-badge status-confirmed">{b.status}</span></td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )
        }

        if (activeTab === 'users') {
            return (
                <div className="card" style={{ background: 'white', padding: '2rem', borderRadius: '20px' }}>
                    <div className="dashboard-section-header">
                        <h2>Registered Users</h2>
                    </div>
                    <table className="data-table" style={{ marginTop: '1rem' }}>
                        <thead>
                            <tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th></tr>
                        </thead>
                        <tbody>
                            {users.map(u => (
                                <tr key={u.id}>
                                    <td>#{u.id}</td>
                                    <td style={{ fontWeight: '500' }}>{u.name}</td>
                                    <td>{u.email}</td>
                                    <td><span className="status-badge" style={{ background: '#eef2ff', color: '#6366f1' }}>{u.role}</span></td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )
        }

        if (activeTab === 'reports') {
            return (
                <div className="card" style={{ background: 'white', padding: '4rem 2rem', borderRadius: '20px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '400px' }}>
                    <div style={{ fontSize: '3rem', marginBottom: '1.5rem' }}>📊</div>
                    <h2 style={{ marginBottom: '1rem' }}>Download Reports</h2>
                    <p style={{ color: 'var(--text-secondary)', marginBottom: '2rem', maxWidth: '400px' }}>
                        Export comprehensive booking data for offline analysis, auditing, and record-keeping purposes.
                    </p>
                    <div style={{ display: 'flex', gap: '1rem' }}>
                        <button onClick={() => handleDownloadReport('pdf')} className="btn btn-primary">
                            Download PDF
                        </button>
                        <button onClick={() => handleDownloadReport('csv')} className="btn" style={{ border: '1px solid #e2e8f0' }}>
                            Download CSV
                        </button>
                    </div>
                </div>
            )
        }

        return <div style={{ padding: '2rem' }}>Select a tab to view content</div>;
    };

    return (
        <div className="admin-layout">
            {/* Sidebar */}
            <div className="sidebar">
                <div className="brand-logo">
                    <span style={{ fontSize: '1.8rem' }}>⚡</span>
                    <span style={{ background: 'linear-gradient(to right, #6366f1, #a855f7)', WebkitBackgroundClip: 'text', color: 'transparent' }}>EventMaster</span>
                </div>
                <div className="nav-links">
                    <button onClick={() => setActiveTab('dashboard')} className={`nav-item ${activeTab === 'dashboard' ? 'active' : ''}`}>
                        <span className="icon">🏠</span> Dashboard
                    </button>
                    <button onClick={() => setActiveTab('events')} className={`nav-item ${activeTab === 'events' ? 'active' : ''}`}>
                        <span className="icon">📅</span> Events
                    </button>
                    <button onClick={() => setActiveTab('bookings')} className={`nav-item ${activeTab === 'bookings' ? 'active' : ''}`}>
                        <span className="icon">🎟️</span> Bookings
                    </button>
                    <button onClick={() => setActiveTab('users')} className={`nav-item ${activeTab === 'users' ? 'active' : ''}`}>
                        <span className="icon">👥</span> Users
                    </button>
                    <button onClick={() => setActiveTab('reports')} className={`nav-item ${activeTab === 'reports' ? 'active' : ''}`}>
                        <span className="icon">📊</span> Reports
                    </button>
                </div>

                <div style={{ marginTop: 'auto', paddingTop: '2rem', borderTop: '1px solid #f1f5f9' }}>
                    <button className="nav-item" style={{ color: '#ef4444' }}>
                        <span className="icon">🚪</span> Logout
                    </button>
                </div>
            </div>

            {/* Main Content */}
            <div className="main-content">
                <header className="dashboard-header">
                    <div className="search-bar">
                        <span style={{ marginRight: '10px' }}>🔍</span>
                        <input type="text" placeholder="Search..." style={{ border: 'none', outline: 'none', width: '100%' }} />
                    </div>
                    <div className="profile-section">
                        <div className="profile-pic"></div>
                        <span style={{ fontWeight: '600' }}>Admin</span>
                    </div>
                </header>

                <div className="content-grid">
                    {renderContent()}
                </div>
            </div>
        </div>
    );
};

export default AdminDashboard;
