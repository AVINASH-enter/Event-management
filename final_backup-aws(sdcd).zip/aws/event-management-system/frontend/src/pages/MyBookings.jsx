import React, { useEffect, useState } from 'react';
import api from '../api/axios';

const MyBookings = () => {
    const [bookings, setBookings] = useState([]);

    const fetchBookings = async () => {
        try {
            const res = await api.get('/bookings/my');
            setBookings(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    useEffect(() => {
        fetchBookings();
    }, []);

    const handleCancel = async (id) => {
        if (!window.confirm("Are you sure you want to cancel this booking?")) return;
        try {
            await api.post(`/bookings/cancel/${id}`);
            fetchBookings(); // Refresh list
            alert("Booking cancelled.");
        } catch (err) {
            alert("Cancellation failed: " + err.response?.data);
        }
    };

    return (
        <div className="my-bookings">
            <h1>My Bookings</h1>
            <div className="bookings-list">
                {bookings.map(booking => (
                    <div key={booking.id} className="booking-card" style={{ border: '1px solid #ccc', padding: '1rem', margin: '1rem 0' }}>
                        <h3>{booking.event.title}</h3>
                        <p>Date: {new Date(booking.event.dateTime).toLocaleString()}</p>
                        <p>Quantity: {booking.quantity}</p>
                        <p>Status: <strong>{booking.status}</strong></p>
                        <p>Total Paid: ${booking.event.price * booking.quantity}</p>

                        {booking.qrCodeUrl && booking.status === 'CONFIRMED' && (
                            <img src={booking.qrCodeUrl} alt="Booking QR" style={{ width: '150px' }} />
                        )}

                        {booking.status === 'CONFIRMED' && (
                            <button onClick={() => handleCancel(booking.id)} style={{ backgroundColor: 'red', marginLeft: '1rem' }}>
                                Cancel Booking
                            </button>
                        )}
                    </div>
                ))}
                {bookings.length === 0 && <p>You have no bookings yet.</p>}
            </div>
        </div>
    );
};

export default MyBookings;
