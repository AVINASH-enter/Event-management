import React, { useState } from 'react';
import api from '../api/axios';
import { useNavigate } from 'react-router-dom';

const EventForm = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        title: '',
        description: '',
        dateTime: '',
        location: '',
        price: '',
        category: '',
        totalSeats: '',
        imageUrl: ''
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await api.post('/events', formData);
            alert('Event created successfully');
            navigate('/admin');
        } catch (err) {
            console.error(err);
            const errorMessage = err.response?.data?.message || err.message || 'Failed to create event';
            alert(`Failed to create event: ${errorMessage}`);
        }
    };

    return (
        <div className="auth-form" style={{ maxWidth: '600px' }}>
            <h2>Create New Event</h2>
            <form onSubmit={handleSubmit}>
                <input name="title" placeholder="Title" onChange={handleChange} required />
                <textarea name="description" placeholder="Description" onChange={handleChange} required style={{ width: '100%', marginBottom: '1rem' }} />
                <input name="dateTime" type="datetime-local" onChange={handleChange} required />
                <input name="location" placeholder="Location" onChange={handleChange} required />
                <input name="price" type="number" placeholder="Price" onChange={handleChange} required />
                <select name="category" onChange={handleChange} required>
                    <option value="">Select Category</option>
                    <option value="Music">Music</option>
                    <option value="Tech">Tech</option>
                    <option value="Sports">Sports</option>
                    <option value="Workshop">Workshop</option>
                </select>
                <input name="totalSeats" type="number" placeholder="Total Seats" onChange={handleChange} required />
                <input name="imageUrl" placeholder="Image URL" onChange={handleChange} />
                <button type="submit">Create Event</button>
            </form>
        </div>
    );
};

export default EventForm;
