import React, { useEffect, useState } from 'react';
import api from '../api/axios';
import { Link } from 'react-router-dom';

const Home = () => {
    const [events, setEvents] = useState([]);
    const [filters, setFilters] = useState({
        keyword: '',
        category: ''
    });

    const fetchEvents = async (customFilters = null) => {
        try {
            const activeFilters = customFilters || filters;
            const params = {};
            if (activeFilters.keyword) params.keyword = activeFilters.keyword.trim();
            if (activeFilters.category) params.category = activeFilters.category;

            console.log("Fetching events with params:", params); // Debug log

            const res = await api.get('/events', { params });
            setEvents(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    useEffect(() => {
        fetchEvents();
    }, []); // Initial load

    const handleFilterChange = (e) => {
        setFilters({ ...filters, [e.target.name]: e.target.value });
    };

    const handleSearch = (e) => {
        e.preventDefault();
        fetchEvents();
    };

    return (
        <div className="home container">
            <section className="hero">
                <h1>Find Your Next Experience</h1>
                <p style={{ fontSize: '1.2rem', opacity: 0.9, marginBottom: '2rem' }}>Discover concerts, workshops, and events happening around you.</p>
                <form onSubmit={handleSearch} className="search-bar">
                    <input
                        type="text"
                        name="keyword"
                        placeholder="Search events, locations..."
                        value={filters.keyword}
                        onChange={handleFilterChange}
                        style={{ flex: 2 }}
                    />
                    <select name="category" value={filters.category} onChange={handleFilterChange} style={{ flex: 1 }}>
                        <option value="">All Categories</option>
                        <option value="Music">Music</option>
                        <option value="Tech">Tech</option>
                        <option value="Sports">Sports</option>
                        <option value="Workshop">Workshop</option>
                    </select>

                    <button type="submit">Search</button>
                    {(filters.keyword || filters.category) && (
                        <button
                            type="button"
                            className="btn-outline"
                            onClick={() => {
                                const emptyFilters = { keyword: '', category: '' };
                                setFilters(emptyFilters);
                                fetchEvents(emptyFilters);
                            }}
                            style={{
                                marginLeft: '0.5rem',
                                padding: '1rem 1.5rem',
                                borderRadius: '50px',
                                border: '1px solid var(--primary)',
                                color: 'var(--primary)',
                                fontWeight: '600',
                                background: 'transparent'
                            }}
                        >
                            View All
                        </button>
                    )}
                </form>
            </section>

            <h2 className="event-section-title">Upcoming Events</h2>
            <div className="grid-cards">
                {events.map(event => (
                    <div key={event.id} className="card event-card">
                        {event.imageUrl ? (
                            <img src={event.imageUrl} alt={event.title} className="event-image" />
                        ) : (
                            <div className="event-image" style={{ backgroundColor: '#e2e8f0', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8' }}>No Image</div>
                        )}
                        <div className="event-info">
                            <span className="event-date">
                                {new Date(event.dateTime).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                            </span>
                            <h3>{event.title}</h3>
                            <p className="event-location">📍 {event.location}</p>
                            <div className="flex-between">
                                <p className="event-price">${event.price}</p>
                                <span style={{ fontSize: '0.85rem', padding: '0.2rem 0.6rem', borderRadius: '20px', background: '#f1f5f9', color: '#64748b' }}>{event.category}</span>
                            </div>
                            <Link to={`/events/${event.id}`} className="view-details-btn">View Details</Link>
                        </div>
                    </div>
                ))}
            </div>
            {events.length === 0 && (
                <div style={{ textAlign: 'center', padding: '4rem', color: '#94a3b8' }}>
                    <p style={{ marginBottom: '1rem', fontSize: '1.2rem' }}>No events found matching your criteria.</p>
                    <button className="btn btn-outline" onClick={() => {
                        const emptyFilters = { keyword: '', category: '' };
                        setFilters(emptyFilters);
                        fetchEvents(emptyFilters);
                    }}>Clear Filters</button>
                </div>
            )}
        </div>
    );
};

export default Home;
