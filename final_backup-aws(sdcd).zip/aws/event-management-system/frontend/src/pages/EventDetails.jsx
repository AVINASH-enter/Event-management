import React, { useEffect, useState, useContext } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { AuthContext } from '../context/AuthContext';

const EventDetails = () => {
    const { id } = useParams();
    const [event, setEvent] = useState(null);
    const [quantity, setQuantity] = useState(1);
    const { user } = useContext(AuthContext);
    const navigate = useNavigate();
    const [bookingSuccess, setBookingSuccess] = useState(null);

    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchEvent = async () => {
            try {
                const res = await api.get(`/events/${id}`);
                setEvent(res.data);
            } catch (err) {
                console.error(err);
                setError(err.response?.data?.message || err.message || 'Failed to load event');
            }
        };
        fetchEvent();
    }, [id]);

    const handleBook = async () => {
        if (!user) {
            navigate('/login');
            return;
        }

        try {
            const res = await api.post('/bookings', { eventId: event.id, quantity: parseInt(quantity) });
            setBookingSuccess(res.data);
            alert('Booking Successful! Check your email or My Bookings.');
        } catch (err) {
            alert('Booking Failed: ' + (err.response?.data || err.message));
        }
    };

    const formattedDate = event ? new Date(event.dateTime).toLocaleString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    }) : '';

    if (error) return (
        <div className="container" style={{ padding: '4rem 0', textAlign: 'center' }}>
            <div className="card" style={{ padding: '2rem', maxWidth: '500px', margin: '0 auto', borderLeft: '4px solid var(--error)' }}>
                <h2 style={{ color: 'var(--error)', marginBottom: '1rem' }}>Error Loading Event</h2>
                <p style={{ marginBottom: '1.5rem', color: 'var(--text-secondary)' }}>{error}</p>
                <button className="btn btn-primary" onClick={() => navigate('/')}>Back to Events</button>
            </div>
        </div>
    );

    if (!event) return (
        <div className="flex-center" style={{ minHeight: '60vh' }}>
            <div className="spinner"></div>
            <p style={{ marginLeft: '1rem', color: 'var(--text-secondary)' }}>Loading event details...</p>
        </div>
    );

    return (
        <div className="event-details-page fade-in">
            <div className="container">
                <button className="btn btn-text" onClick={() => navigate(-1)} style={{ marginBottom: '1rem', paddingLeft: 0 }}>
                    ← Back
                </button>

                <div className="event-top-section">
                    <div className="event-image-container">
                        {event.imageUrl ? (
                            <img
                                src={event.imageUrl}
                                alt={event.title}
                                className="detail-hero-image"
                            />
                        ) : (
                            <div className="detail-image-placeholder">No Image Available</div>
                        )}
                    </div>

                    <div className="event-booking-container">
                        <div className="booking-card">
                            {!bookingSuccess ? (
                                <>
                                    <div className="price-tag">
                                        <span className="label">Price per ticket</span>
                                        <span className="amount">${event.price}</span>
                                    </div>

                                    <div className="seats-info">
                                        <div className="progress-bar">
                                            <div
                                                className="progress"
                                                style={{ width: `${(event.availableSeats / event.totalSeats) * 100}%` }}
                                            ></div>
                                        </div>
                                        <p>{event.availableSeats} seats remaining</p>
                                    </div>

                                    {event.availableSeats > 0 ? (
                                        <div className="booking-form">
                                            <div className="form-group">
                                                <label>Quantity</label>
                                                <div className="quantity-control">
                                                    <button
                                                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                                                        className="qty-btn"
                                                    >-</button>
                                                    <input
                                                        type="number"
                                                        min="1"
                                                        max={event.availableSeats}
                                                        value={quantity}
                                                        onChange={(e) => setQuantity(Math.max(1, Math.min(event.availableSeats, parseInt(e.target.value) || 1)))}
                                                        readOnly
                                                    />
                                                    <button
                                                        onClick={() => setQuantity(Math.min(event.availableSeats, quantity + 1))}
                                                        className="qty-btn"
                                                    >+</button>
                                                </div>
                                            </div>

                                            <div className="total-price">
                                                <span>Total:</span>
                                                <span>${(event.price * quantity).toFixed(2)}</span>
                                            </div>

                                            <button className="btn btn-primary btn-block" onClick={handleBook}>
                                                Book Now
                                            </button>
                                        </div>
                                    ) : (
                                        <div className="sold-out-badge">Sold Out</div>
                                    )}
                                </>
                            ) : (
                                <div className="success-message">
                                    <div className="success-icon">🎉</div>
                                    <h3>Booking Confirmed!</h3>
                                    <p>Your tickets have been sent to your email.</p>
                                    <div className="ticket-summary">
                                        <p><strong>Booking ID:</strong> #{bookingSuccess.id}</p>
                                        <p><strong>Quantity:</strong> {bookingSuccess.quantity}</p>
                                    </div>
                                    {bookingSuccess.qrCodeUrl && (
                                        <div className="qr-code">
                                            <img src={bookingSuccess.qrCodeUrl} alt="Ticket QR" />
                                        </div>
                                    )}
                                    <button className="btn btn-outline btn-block" onClick={() => navigate('/my-bookings')}>
                                        View My Bookings
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                <div className="event-bottom-section">
                    <div className="event-header">
                        <span className="badge category-badge">{event.category}</span>
                        <h1>{event.title}</h1>
                        <div className="event-meta">
                            <p className="meta-item">
                                <span className="icon">📅</span> {formattedDate}
                            </p>
                            <p className="meta-item">
                                <span className="icon">📍</span> {event.location}
                            </p>
                        </div>
                    </div>

                    <div className="event-description">
                        <h3>About this Event</h3>
                        <p>{event.description}</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default EventDetails;
