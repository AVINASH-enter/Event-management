# Event Management System - Testing Guide

This guide details how to valid the user flows of the Event Management System.

## 1. Prerequisites
Ensure both the backend and frontend are running.

**Backend (Terminal 1):**
```bash
cd backend
./mvnw spring-boot:run
```

**Frontend (Terminal 2):**
```bash
cd frontend
npm install
npm run dev
```

---

## 2. Manual Testing Scenarios

### Scenario A: User Registration & Login
1.  **Navigate to** `http://localhost:5173/register`
2.  **Action:** Fill in Name, Email, Password. Click "Register".
3.  **Expected Result:** Success message "User registered successfully!".
4.  **Navigate to** `http://localhost:5173/login`
5.  **Action:** Enter the registered Email and Password. Click "Login".
6.  **Expected Result:** Redirect to Home/Dashboard. JWT token stored (check DevTools -> Application -> Local Storage).

### Scenario B: Browsing & Booking Events
1.  **Navigate to** `http://localhost:5173/` (Home)
2.  **Action:** Click on an event card.
3.  **Expected Result:** Redirect to `http://localhost:5173/events/{id}` showing event details.
4.  **Action:** Click "Book Event" button.
5.  **Expected Result:** Success message.
6.  **Navigate to** `http://localhost:5173/my-bookings`
7.  **Expected Result:** The booked event appears in the list.

### Scenario C: Admin Event Creation (Admin Role Required)
*Prerequisite: User must be registered with ADMIN role.*
1.  **Navigate to** `http://localhost:5173/admin/events/new`
2.  **Action:** Fill in Event Title, Description, Date, Location. Click "Create".
3.  **Expected Result:** Success message.
4.  **Navigate to** `http://localhost:5173/`
5.  **Expected Result:** New event appears on the homepage.

---

## 3. Automated Testing (Recommended)

Since the project uses generic React + Vite, **Cypress** is recommended for End-to-End (E2E) testing.

**Note:** Cypress is not currently installed. To set it up:

### Setup Cypress
1.  Run `npm install --save-dev cypress` in `frontend/`.
2.  Open Cypress: `npx cypress open`
3.  Choose **E2E Testing** -> **Chrome**.
4.  Create a test spec file (e.g., `frontend/cypress/e2e/auth.cy.js`).

### Example Test File (`frontend/cypress/e2e/auth.cy.js`)
```javascript
describe('User Authentication Flow', () => {
  it('should register and login successfully', () => {
    // 1. Visit Register Page
    cy.visit('http://localhost:5173/register');
    
    // 2. Fill Form
    cy.get('input[name="name"]').type('Test User');
    cy.get('input[name="email"]').type('test@example.com');
    cy.get('input[name="password"]').type('password123');
    // Note: Adjust selector based on actual button text/class
    cy.contains('button', 'Register').click();

    // 3. Verify Registration Success
    cy.contains('User registered successfully!').should('be.visible');

    // 4. Login
    cy.visit('http://localhost:5173/login');
    cy.get('input[name="email"]').type('test@example.com');
    cy.get('input[name="password"]').type('password123');
    // Note: Adjust selector based on actual button text/class
    cy.contains('button', 'Login').click();

    // 5. Verify Redirect
    cy.url().should('include', '/');
  });
});
```

## 4. Backend API Testing (Postman/cURL)
If the frontend is incomplete, test the API directly.

**Login Request:**
```bash
curl -X POST http://localhost:8080/api/auth/signin \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com", "password":"password"}'
```
