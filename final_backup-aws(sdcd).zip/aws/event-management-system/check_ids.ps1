try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/events" -Method GET
    $events = $response.Content | ConvertFrom-Json
    Write-Output "Total Events: $($events.Count)"
    if ($events.Count -gt 0) {
        Write-Output "Available IDs: $($events.id -join ', ')"
    }
    else {
        Write-Output "No events found."
    }
}
catch {
    Write-Output "Error fetching events: $_"
}
