package com.example.event_backend.service;

import com.example.event_backend.entity.Event;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface EventService {
    List<Event> getAllEvents(String keyword, String category, BigDecimal maxPrice, LocalDateTime startDate);
    Optional<Event> getEventById(Long id);
    Event createEvent(Event event);
    Event updateEvent(Long id, Event eventDetails);
    void deleteEvent(Long id);
}
