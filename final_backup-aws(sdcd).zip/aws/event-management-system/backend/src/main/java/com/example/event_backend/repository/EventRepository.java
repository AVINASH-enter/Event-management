package com.example.event_backend.repository;

import com.example.event_backend.entity.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public interface EventRepository extends JpaRepository<Event, Long> {
    
    List<Event> findByCategory(String category);
    
    List<Event> findByPriceLessThanEqual(BigDecimal price);
    
    List<Event> findByDateTimeAfter(LocalDateTime date);
    
    @Query("SELECT e FROM Event e WHERE " +
           "(:keyword IS NULL OR LOWER(e.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(e.description) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(e.location) LIKE LOWER(CONCAT('%', :keyword, '%'))) AND " +
           "(:category IS NULL OR e.category = :category) AND " +
           "(:maxPrice IS NULL OR e.price <= :maxPrice) AND " +
           "(:startDate IS NULL OR e.dateTime >= :startDate)")
    List<Event> searchEvents(@Param("keyword") String keyword, 
                             @Param("category") String category, 
                             @Param("maxPrice") BigDecimal maxPrice, 
                             @Param("startDate") LocalDateTime startDate);
}
