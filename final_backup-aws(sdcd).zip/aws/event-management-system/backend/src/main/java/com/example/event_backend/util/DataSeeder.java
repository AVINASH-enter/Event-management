package com.example.event_backend.util;

import com.example.event_backend.entity.Event;
import com.example.event_backend.repository.EventRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@Component
public class DataSeeder implements CommandLineRunner {

        private final EventRepository eventRepository;

        public DataSeeder(EventRepository eventRepository) {
                this.eventRepository = eventRepository;
        }

        @Override
        public void run(String... args) throws Exception {
                if (eventRepository.count() > 0) {
                        eventRepository.deleteAll();
                }
                if (eventRepository.count() == 0) {
                        seedEvents();
                }
        }

        private void seedEvents() {
                List<Event> events = Arrays.asList(
                                Event.builder()
                                                .title("Tech Innovation Summit 2024")
                                                .description(
                                                                "Join us for a day of cutting-edge technology discussions, workshops, and networking with industry leaders. Topics include AI, Blockchain, and Cloud Computing.")
                                                .dateTime(LocalDateTime.now().plusDays(10).withHour(9).withMinute(0))
                                                .location("Convention Center, San Francisco")
                                                .price(new BigDecimal("299.99"))
                                                .category("Tech")
                                                .totalSeats(500)
                                                .availableSeats(500)
                                                .imageUrl(
                                                                "https://images.unsplash.com/photo-1540575467063-178a50c2df87?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80")
                                                .build(),

                                Event.builder()
                                                .title("Summer Music Festival")
                                                .description(
                                                                "Experience the best indie and rock bands live under the stars. Food trucks, art installations, and great vibes guaranteed.")
                                                .dateTime(LocalDateTime.now().plusDays(25).withHour(16).withMinute(0))
                                                .location("Central Park, New York")
                                                .price(new BigDecimal("89.50"))
                                                .category("Music")
                                                .totalSeats(2000)
                                                .availableSeats(1950)
                                                .imageUrl(
                                                                "https://images.unsplash.com/photo-1459749411177-d4a42849e812?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80")
                                                .build(),

                                Event.builder()
                                                .title("Yoga & Mindfulness Retreat")
                                                .description(
                                                                "Disconnect from the hustle and bustle. A weekend of yoga sessions, meditation, and healthy living in a serene environment.")
                                                .dateTime(LocalDateTime.now().plusDays(15).withHour(8).withMinute(0))
                                                .location("Peaceful Valley Resort, Colorado")
                                                .price(new BigDecimal("450.00"))
                                                .category("Workshop")
                                                .totalSeats(50)
                                                .availableSeats(42)
                                                .imageUrl(
                                                                "https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80")
                                                .build(),

                                Event.builder()
                                                .title("City Marathon 2024")
                                                .description(
                                                                "Challenge yourself in the annual city marathon. Open to all skill levels. Proceeds go to local charities.")
                                                .dateTime(LocalDateTime.now().plusDays(40).withHour(6).withMinute(30))
                                                .location("City Hall Start Line, Chicago")
                                                .price(new BigDecimal("55.00"))
                                                .category("Sports")
                                                .totalSeats(3000)
                                                .availableSeats(2500)
                                                .imageUrl(
                                                                "https://images.unsplash.com/photo-1552674605-46d536d2348c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80")
                                                .build(),

                                Event.builder()
                                                .title("Digital Marketing Masterclass")
                                                .description(
                                                                "Learn the latest strategies in SEO, social media marketing, and content creation from top experts.")
                                                .dateTime(LocalDateTime.now().plusDays(5).withHour(10).withMinute(0))
                                                .location("Online Webinar")
                                                .price(new BigDecimal("49.99"))
                                                .category("Workshop")
                                                .totalSeats(1000)
                                                .availableSeats(980)
                                                .imageUrl(
                                                                "https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1074&q=80")
                                                .build(),

                                Event.builder()
                                                .title("Jazz Night at The Blue Note")
                                                .description(
                                                                "An intimate evening of smooth jazz performances by the Oscar Peterson Trio tribute band.")
                                                .dateTime(LocalDateTime.now().plusDays(3).withHour(20).withMinute(0))
                                                .location("The Blue Note, New Orleans")
                                                .price(new BigDecimal("35.00"))
                                                .category("Music")
                                                .totalSeats(100)
                                                .availableSeats(15)
                                                .imageUrl(
                                                                "https://images.unsplash.com/photo-1511192336575-5a79af67a629?ixlib=rb-4.0.3&auto=format&fit=crop&w=1632&q=80")
                                                .build(),

                                Event.builder()
                                                .title("Gourmet Food Truck Festival")
                                                .description("A gathering of the city's best food trucks offering a variety of cuisines.")
                                                .dateTime(LocalDateTime.now().plusDays(12).withHour(11).withMinute(0))
                                                .location("Downtown Park, Austin")
                                                .price(new BigDecimal("0.00"))
                                                .category("Food & Drink")
                                                .totalSeats(1000)
                                                .availableSeats(1000)
                                                .imageUrl("https://images.unsplash.com/photo-1565123409695-7b5ef63a7453?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80")
                                                .build(),

                                Event.builder()
                                                .title("Startup Pitch Night")
                                                .description("Watch local startups pitch their ideas to investors and win prizes.")
                                                .dateTime(LocalDateTime.now().plusDays(18).withHour(18).withMinute(0))
                                                .location("Innovation Hub, San Francisco")
                                                .price(new BigDecimal("20.00"))
                                                .category("Business")
                                                .totalSeats(150)
                                                .availableSeats(120)
                                                .imageUrl("https://images.unsplash.com/photo-1559136555-9303baea8ebd?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80")
                                                .build(),

                                Event.builder()
                                                .title("Art Gallery Opening: Modern Visions")
                                                .description("Grand opening of a new exhibition featuring contemporary artists.")
                                                .dateTime(LocalDateTime.now().plusDays(7).withHour(19).withMinute(0))
                                                .location("Metropolitan Gallery, New York")
                                                .price(new BigDecimal("50.00"))
                                                .category("Arts")
                                                .totalSeats(200)
                                                .availableSeats(180)
                                                .imageUrl("https://images.unsplash.com/photo-1536924940846-227afb31e2a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1166&q=80")
                                                .build(),

                                Event.builder()
                                                .title("Weekend Coding Bootcamp")
                                                .description("Intensive weekend workshop covering HTML, CSS, and JavaScript basics.")
                                                .dateTime(LocalDateTime.now().plusDays(20).withHour(9).withMinute(0))
                                                .location("Tech Campus, Seattle")
                                                .price(new BigDecimal("150.00"))
                                                .category("Education")
                                                .totalSeats(30)
                                                .availableSeats(25)
                                                .imageUrl("https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80")
                                                .build(),

                                Event.builder()
                                                .title("Community Clean-Up Day")
                                                .description("Join your neighbors in cleaning up the local park and streets.")
                                                .dateTime(LocalDateTime.now().plusDays(8).withHour(10).withMinute(0))
                                                .location("Community Park, Chicago")
                                                .price(new BigDecimal("0.00"))
                                                .category("Charity")
                                                .totalSeats(500)
                                                .availableSeats(500)
                                                .imageUrl("https://images.unsplash.com/photo-1559027615-cd4628902d4a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1174&q=80")
                                                .build(),

                                Event.builder()
                                                .title("Stand-up Comedy Night")
                                                .description("A hilarious night featuring top local and national comedians.")
                                                .dateTime(LocalDateTime.now().plusDays(14).withHour(20).withMinute(30))
                                                .location("The Laugh Club, Los Angeles")
                                                .price(new BigDecimal("25.00"))
                                                .category("Entertainment")
                                                .totalSeats(100)
                                                .availableSeats(80)
                                                .imageUrl("https://images.unsplash.com/photo-1585699324551-f6c309eedeca?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80")
                                                .build(),

                                Event.builder()
                                                .title("Photography Workshop: Urban Landscapes")
                                                .description("Learn to capture stunning cityscapes with professional guidance.")
                                                .dateTime(LocalDateTime.now().plusDays(22).withHour(16).withMinute(0))
                                                .location("Skyline Point, Chicago")
                                                .price(new BigDecimal("75.00"))
                                                .category("Workshop")
                                                .totalSeats(20)
                                                .availableSeats(15)
                                                .imageUrl("https://images.unsplash.com/photo-1516035069371-29a1b244cc32?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80")
                                                .build(),

                                Event.builder()
                                                .title("Local Farmers Market")
                                                .description("Fresh produce, homemade goods, and live music every Saturday.")
                                                .dateTime(LocalDateTime.now().plusDays(1).withHour(8).withMinute(0))
                                                .location("Town Square, Portland")
                                                .price(new BigDecimal("0.00"))
                                                .category("Food & Drink")
                                                .totalSeats(1000)
                                                .availableSeats(1000)
                                                .imageUrl("https://images.unsplash.com/photo-1488459716781-31db52582fe9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80")
                                                .build(),

                                Event.builder()
                                                .title("Historical Walking Tour")
                                                .description("Discover the rich history of the old town with an expert guide.")
                                                .dateTime(LocalDateTime.now().plusDays(6).withHour(14).withMinute(0))
                                                .location("Old Town, Boston")
                                                .price(new BigDecimal("15.00"))
                                                .category("Culture")
                                                .totalSeats(30)
                                                .availableSeats(28)
                                                .imageUrl("https://images.unsplash.com/photo-1582063289852-62e3ba2747f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80")
                                                .build(),

                                Event.builder()
                                                .title("Science Fair 2024")
                                                .description("Showcasing innovative science projects from students across the region.")
                                                .dateTime(LocalDateTime.now().plusDays(30).withHour(10).withMinute(0))
                                                .location("Science Museum, Seattle")
                                                .price(new BigDecimal("5.00"))
                                                .category("Education")
                                                .totalSeats(500)
                                                .availableSeats(450)
                                                .imageUrl("https://images.unsplash.com/photo-1532094349884-543bc11b234d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80")
                                                .build());

                eventRepository.saveAll(events);
                System.out.println("Sample events have been seeded successfully!");
        }
}
