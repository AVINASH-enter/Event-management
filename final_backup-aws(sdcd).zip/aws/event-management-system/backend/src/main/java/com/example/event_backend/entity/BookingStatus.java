package com.example.event_backend.entity;

public enum BookingStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}
