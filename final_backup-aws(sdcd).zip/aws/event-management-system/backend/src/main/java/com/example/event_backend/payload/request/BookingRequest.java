package com.example.event_backend.payload.request;

import lombok.Data;

@Data
public class BookingRequest {
    private Long eventId;
    private Integer quantity;
}
