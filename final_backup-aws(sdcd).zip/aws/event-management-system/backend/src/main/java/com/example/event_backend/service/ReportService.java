package com.example.event_backend.service;

import com.example.event_backend.entity.Booking;
import com.example.event_backend.repository.BookingRepository;
import com.itextpdf.text.*;

import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;

@Service
public class ReportService {

    @Autowired
    private BookingRepository bookingRepository;

    public ByteArrayInputStream generateBookingReportPdf() {
        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            Font font = FontFactory.getFont(FontFactory.COURIER, 14, BaseColor.BLACK);
            Paragraph para = new Paragraph("Booking Report", font);
            para.setAlignment(Element.ALIGN_CENTER);
            document.add(para);
            document.add(Chunk.NEWLINE);

            PdfPTable table = new PdfPTable(5);
            table.addCell("Booking ID");
            table.addCell("User Email");
            table.addCell("Event");
            table.addCell("Date");
            table.addCell("Quantity");

            List<Booking> bookings = bookingRepository.findAll();

            for (Booking booking : bookings) {
                table.addCell(String.valueOf(booking.getId()));
                table.addCell(booking.getUser().getEmail());
                table.addCell(booking.getEvent().getTitle());
                table.addCell(booking.getBookingDate().toString());
                table.addCell(String.valueOf(booking.getQuantity()));
            }

            document.add(table);
            document.close();

        } catch (DocumentException e) {
            e.printStackTrace();
        }

        return new ByteArrayInputStream(out.toByteArray());
    }

    public ByteArrayInputStream generateBookingReportCsv() {
        List<Booking> bookings = bookingRepository.findAll();
        StringBuilder csvContent = new StringBuilder();
        csvContent.append("Booking ID,User Email,Event,Date,Quantity\n");

        for (Booking booking : bookings) {
            csvContent.append(booking.getId()).append(",")
                    .append(booking.getUser().getEmail()).append(",")
                    .append(booking.getEvent().getTitle()).append(",")
                    .append(booking.getBookingDate()).append(",")
                    .append(booking.getQuantity()).append("\n");
        }

        return new ByteArrayInputStream(csvContent.toString().getBytes());
    }
}
