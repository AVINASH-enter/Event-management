package com.example.event_backend.service;

import com.example.event_backend.entity.Booking;
import com.example.event_backend.payload.request.BookingRequest;
import java.util.List;

public interface BookingService {
    Booking createBooking(Long userId, BookingRequest bookingRequest);
    List<Booking> getUserBookings(Long userId);
    List<Booking> getAllBookings(); // Admin
    void cancelBooking(Long bookingId, Long userId);
}
