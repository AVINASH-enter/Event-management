package com.example.event_backend.entity;

public enum Role {
    USER,
    ADMIN
}
