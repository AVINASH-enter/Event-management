package com.example.event_backend.service.impl;

import com.example.event_backend.entity.Event;
import com.example.event_backend.repository.EventRepository;
import com.example.event_backend.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class EventServiceImpl implements EventService {

    @Autowired
    private EventRepository eventRepository;

    @Override
    public List<Event> getAllEvents(String keyword, String category, BigDecimal maxPrice, LocalDateTime startDate) {
        if (keyword == null && category == null && maxPrice == null && startDate == null) {
            return eventRepository.findAll();
        }
        return eventRepository.searchEvents(keyword, category, maxPrice, startDate);
    }

    @Override
    public Optional<Event> getEventById(Long id) {
        return eventRepository.findById(id);
    }

    @Override
    public Event createEvent(Event event) {
        return eventRepository.save(event);
    }

    @Override
    public Event updateEvent(Long id, Event eventDetails) {
        Event event = eventRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Event not found for this id :: " + id));

        event.setTitle(eventDetails.getTitle());
        event.setDescription(eventDetails.getDescription());
        event.setDateTime(eventDetails.getDateTime());
        event.setLocation(eventDetails.getLocation());
        event.setPrice(eventDetails.getPrice());
        event.setCategory(eventDetails.getCategory());
        event.setTotalSeats(eventDetails.getTotalSeats());
        event.setAvailableSeats(eventDetails.getAvailableSeats()); // Or calculate
        event.setImageUrl(eventDetails.getImageUrl());

        return eventRepository.save(event);
    }

    @Override
    public void deleteEvent(Long id) {
        Event event = eventRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Event not found for this id :: " + id));
        eventRepository.delete(event);
    }
}
