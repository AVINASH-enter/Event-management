package com.example.event_backend.service.impl;

import com.example.event_backend.entity.Booking;
import com.example.event_backend.entity.BookingStatus;
import com.example.event_backend.entity.Event;
import com.example.event_backend.entity.User;
import com.example.event_backend.payload.request.BookingRequest;
import com.example.event_backend.repository.BookingRepository;
import com.example.event_backend.repository.EventRepository;
import com.example.event_backend.repository.UserRepository;
import com.example.event_backend.service.BookingService;
import com.example.event_backend.service.EmailService;
import com.example.event_backend.util.QrCodeGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;

@Service
public class BookingServiceImpl implements BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private QrCodeGenerator qrCodeGenerator;
    
    @Autowired
    private EmailService emailService;

    @Override
    @Transactional
    public Booking createBooking(Long userId, BookingRequest bookingRequest) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Event event = eventRepository.findById(bookingRequest.getEventId())
                .orElseThrow(() -> new RuntimeException("Event not found"));

        if (event.getAvailableSeats() < bookingRequest.getQuantity()) {
            throw new RuntimeException("Not enough seats available");
        }

        // Update seats
        event.setAvailableSeats(event.getAvailableSeats() - bookingRequest.getQuantity());
        eventRepository.save(event);

        Booking booking = Booking.builder()
                .user(user)
                .event(event)
                .quantity(bookingRequest.getQuantity())
                .bookingDate(LocalDateTime.now())
                .status(BookingStatus.CONFIRMED)
                .build();
        
        // Generate QR content (Booking ID + User Email)
        String qrContent = "BookingID:" + booking.getId() + ";User:" + user.getEmail(); 
        // Note: Booking ID is null before save, so we might need to save first or use other unique data.
        // Let's save first.
        booking = bookingRepository.save(booking);
        
        try {
            qrContent = "BookingID:" + booking.getId() + ";Event:" + event.getTitle();
            byte[] qrImage = qrCodeGenerator.generateQrCodeImage(qrContent, 200, 200);
            String qrBase64 = Base64.getEncoder().encodeToString(qrImage);
            booking.setQrCodeUrl("data:image/png;base64," + qrBase64); // Store as data URL for frontend
            bookingRepository.save(booking);
            
            // Send Email
            String emailBody = "<h1>Booking Confirmed!</h1>" +
                    "<p>Event: " + event.getTitle() + "</p>" +
                    "<p>Date: " + event.getDateTime() + "</p>" +
                    "<p>Quantity: " + booking.getQuantity() + "</p>" +
                    "<p>Total Price: $" + event.getPrice().multiply(new java.math.BigDecimal(booking.getQuantity())) + "</p>";
            
            emailService.sendBookingConfirmation(user.getEmail(), "Ticket Confirmation - " + event.getTitle(), emailBody, qrImage);
            
        } catch (Exception e) {
            e.printStackTrace();
        }

        return booking;
    }

    @Override
    public List<Booking> getUserBookings(Long userId) {
        return bookingRepository.findByUserId(userId);
    }

    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @Override
    @Transactional
    public void cancelBooking(Long bookingId, Long userId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));
        
        if (!booking.getUser().getId().equals(userId)) {
             throw new RuntimeException("Unauthorized cancellation");
        }

        if (booking.getStatus() == BookingStatus.CANCELLED) {
            throw new RuntimeException("Booking already cancelled");
        }
        
        // Restore seats
        Event event = booking.getEvent();
        event.setAvailableSeats(event.getAvailableSeats() + booking.getQuantity());
        eventRepository.save(event);

        booking.setStatus(BookingStatus.CANCELLED);
        bookingRepository.save(booking);
    }
}
