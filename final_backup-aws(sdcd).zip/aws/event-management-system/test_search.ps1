$baseUrl = "http://localhost:8081/api/events"

function Test-Endpoint {
    param($Uri, $Description)
    Write-Host "`nRunning: $Description"
    try {
        $encodedUri = [System.Uri]::EscapeUriString($Uri)
        # Note: EscapeUriString depracated but often works for simple cases. 
        # Better to just rely on Invoke-RestMethod if string is clean.
        # But 'Invoke-RestMethod' with spaces in string might need careful handling.
        
        $response = Invoke-RestMethod -Uri $Uri -Method Get -ErrorAction Stop
        Write-Host "Success. Count: $($response.Count)"
        if ($response.Count -gt 0) {
            $response | Select-Object -First 3 | ForEach-Object { Write-Host " - Found: $($_.title)" }
        }
    }
    catch {
        Write-Host "Failed: $_"
        if ($_.Exception.Response) {
            # Read error stream
            $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
            Write-Host "Details: $($reader.ReadToEnd())"
        }
    }
}

Test-Endpoint -Uri $baseUrl -Description "1. GetAll"
Test-Endpoint -Uri "$baseUrl?keyword=Tech" -Description "2. Search 'Tech'"
Test-Endpoint -Uri "$baseUrl?category=Music" -Description "3. Search Category 'Music'"
Test-Endpoint -Uri "$baseUrl?keyword=Festival&category=Food%20%26%20Drink" -Description "4. Complex Search"
Test-Endpoint -Uri "$baseUrl?keyword= Tech " -Description "5. Search with simple whitespace ' Tech ' (Requires Backend Restart)"
