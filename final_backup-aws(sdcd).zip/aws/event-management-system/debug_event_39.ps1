try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/events/39" -Method GET
    Write-Output "Status: $($response.StatusCode)"
    Write-Output $response.Content
} catch {
    Write-Output "Error: $_"
    if ($_.Exception.Response) {
        Write-Output "Status: $($_.Exception.Response.StatusCode)"
    }
}
