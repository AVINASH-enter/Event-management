try {
    $response = Invoke-WebRequest -Uri "http://localhost:8081/api/events" -Method GET
    $events = $response.Content | ConvertFrom-Json
    Write-Output "Count: $($events.Count)"
    if ($events.Count -gt 0) {
        Write-Output "First ID: $($events[0].id)"
        Write-Output "Last ID: $($events[-1].id)"
        Write-Output "All IDs: $($events.id -join ', ')"
    }
}
catch {
    Write-Output "Error: $_"
}
